const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

let current = {
  title: '',
  story: '',
  genre: 'مغامرة',
  rating: 'جميع الأعمار',
  style: '3D كارتوني',
  characters: [],
  scenes: []
};
let sceneIndex = 0;

function go(id){
  $$('.screen').forEach(x=>x.classList.remove('active'));
  $('#'+id).classList.add('active');
  $$('.navitem').forEach(x=>x.classList.remove('active'));
  const nav = $(`.navitem[data-go="${id}"]`);
  if(nav) nav.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(id==='home') renderProjects();
}

$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));

$$('.chip').forEach(c=>c.addEventListener('click',()=>{
  $$('.chip').forEach(x=>x.classList.remove('selected'));
  c.classList.add('selected');
  current.style = c.dataset.style;
}));

$('#themeBtn').addEventListener('click',()=>{
  document.body.classList.toggle('dark');
  localStorage.setItem('hoodtoon_theme', document.body.classList.contains('dark')?'dark':'light');
});
if(localStorage.getItem('hoodtoon_theme')==='dark') document.body.classList.add('dark');

function autoCharacters(story){
  const base = [
    {emoji:'🧑‍🎤',name:'البطل'},
    {emoji:'🦊',name:'الصديق'},
    {emoji:'👑',name:'الشخصية الغامضة'}
  ];
  if(/بنت|فتاة|أميرة/.test(story)) base[0]={emoji:'👧',name:'البطلة'};
  if(/ولد|شاب/.test(story)) base[0]={emoji:'👦',name:'البطل'};
  if(/ملكة/.test(story)) base[2]={emoji:'👸',name:'الملكة'};
  if(/تنين/.test(story)) base[1]={emoji:'🐉',name:'التنين'};
  if(/ثعبان|أفعى/.test(story)) base[1]={emoji:'🐍',name:'الصديق'};
  return base;
}

function autoScenes(story){
  const clean = story.trim() || 'تبدأ مغامرة جديدة في عالم خيالي.';
  const bits = clean.split(/[.!؟\n]+/).map(x=>x.trim()).filter(Boolean);
  const templates = [
    ['🌅','البداية'],['🏙️','الاكتشاف'],['⚡','المشكلة'],['🏃','المطاردة'],['✨','الحل'],['🎉','النهاية']
  ];
  const count = Math.max(4, Math.min(6, bits.length || 4));
  return Array.from({length:count},(_,i)=>({
    icon: templates[i][0],
    title: `المشهد ${i+1} — ${templates[i][1]}`,
    text: bits[i] || (i===count-1 ? 'تنتهي المغامرة برسالة جميلة وأمل جديد.' : 'يتطور الحدث وتظهر مفاجأة جديدة للشخصيات.')
  }));
}

$('#buildBtn').addEventListener('click', async ()=>{
  current.title = $('#title').value.trim() || 'فيلمي الجديد';
  current.story = $('#story').value.trim();
  current.genre = $('#genre').value;
  current.rating = $('#rating').value;
  current.characters = autoCharacters(current.story);
  current.scenes = autoScenes(current.story);

  $('#builderTitle').textContent = current.title;
  go('builder');

  $('#statusText').textContent='جاري تجهيز القصة...';
  $('#progressBar').style.width='25%';
  await wait(350);
  $('#progressBar').style.width='60%';
  $('#statusText').textContent='جاري ترتيب الشخصيات والمشاهد...';
  await wait(450);
  $('#progressBar').style.width='100%';
  $('#statusText').textContent='تم تجهيز الـ Storyboard مجانًا ✓';
  renderBuilder();
});

function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }

function renderBuilder(){
  $('#characters').innerHTML = current.characters.map((c,i)=>`
    <div class="character">
      <div class="avatar">${c.emoji}</div>
      <input value="${escapeHtml(c.name)}" data-char="${i}">
    </div>`).join('');
  $$('[data-char]').forEach(inp=>inp.addEventListener('input',()=>current.characters[+inp.dataset.char].name=inp.value));

  $('#sceneCount').textContent = `${current.scenes.length} مشاهد`;
  $('#scenes').innerHTML = current.scenes.map((s,i)=>`
    <div class="scene">
      <div class="sceneicon">${s.icon}</div>
      <div>
        <b>${escapeHtml(s.title)}</b>
        <textarea data-scene="${i}">${escapeHtml(s.text)}</textarea>
      </div>
    </div>`).join('');
  $$('[data-scene]').forEach(t=>t.addEventListener('input',()=>current.scenes[+t.dataset.scene].text=t.value));
}

$('#addCharacter').addEventListener('click',()=>{
  current.characters.push({emoji:'🙂',name:`شخصية ${current.characters.length+1}`});
  renderBuilder();
});
$('#addScene').addEventListener('click',()=>{
  current.scenes.push({icon:'🎬',title:`المشهد ${current.scenes.length+1}`,text:'اكتب وصف المشهد هنا...'});
  renderBuilder();
});

$('#previewBtn').addEventListener('click',()=>{
  sceneIndex=0;
  renderPlayer();
  go('preview');
});
function renderPlayer(){
  const s=current.scenes[sceneIndex] || {icon:'🎬',title:'لا توجد مشاهد',text:''};
  $('#playerVisual').textContent=s.icon;
  $('#playerSceneTitle').textContent=s.title;
  $('#playerSceneText').textContent=s.text;
}
$('#prevScene').addEventListener('click',()=>{sceneIndex=Math.max(0,sceneIndex-1);renderPlayer()});
$('#nextScene').addEventListener('click',()=>{sceneIndex=Math.min(current.scenes.length-1,sceneIndex+1);renderPlayer()});
$('#playScene').addEventListener('click',()=>{
  if('speechSynthesis' in window){
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(current.scenes[sceneIndex]?.text || '');
    u.lang='ar';
    speechSynthesis.speak(u);
  } else alert('تشغيل الصوت غير مدعوم بهذا المتصفح.');
});

function saveProject(){
  const projects=JSON.parse(localStorage.getItem('hoodtoon_projects')||'[]');
  const item={...current,id:Date.now(),savedAt:new Date().toISOString()};
  projects.unshift(item);
  localStorage.setItem('hoodtoon_projects',JSON.stringify(projects.slice(0,20)));
}
$('#saveBtn').addEventListener('click',()=>{saveProject();go('published')});
$('#publishBtn').addEventListener('click',()=>{saveProject();go('published')});

function renderProjects(){
  const projects=JSON.parse(localStorage.getItem('hoodtoon_projects')||'[]');
  const box=$('#projects');
  if(!projects.length){
    box.innerHTML='<div class="project"><div class="thumb">🎬</div><b>ما عندك مشاريع بعد</b><small>ابدأ أول كارتون من زر إنشاء</small></div>';
    return;
  }
  box.innerHTML=projects.map(p=>`
    <div class="project">
      <div class="thumb">${p.scenes?.[0]?.icon || '🎬'}</div>
      <b>${escapeHtml(p.title)}</b>
      <small>${escapeHtml(p.genre)} • ${escapeHtml(p.rating)}</small>
    </div>`).join('');
}
$('#clearProjects').addEventListener('click',()=>{
  localStorage.removeItem('hoodtoon_projects');
  renderProjects();
});
$('#aboutBtn').addEventListener('click',()=>$('#aboutDialog').showModal());

function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
renderProjects();
